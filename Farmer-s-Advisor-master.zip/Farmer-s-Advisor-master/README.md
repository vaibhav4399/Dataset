# Farmer-s-Advisor


India is called the land of farmers, as most of the people of the country are directly or indirectly involved in the agriculture sector. 
The condition of most farmers is terrible. About 80% of farmers in India are marginal (less than 1 hectare) or small farmers (1–2 hectare) category. Agriculture supports about 60% of employment but contributes only 17% to GDP. Every day, there are reports of Indian farmer suicides from different parts of the country. 

To improve the condition of the farmers we have implemented a Mobile and Web application using which farmers can analyze the yield production of crops in the given environmental conditions and picks the crop that will give the maximum yield. 

In the implementation of the above Machine Learning models have been used which gives the production of crops by analyzing the production of the past 10 years in that particular place.
